#' Estimate the effect size of a potential hidden mediator between a continuous trait of interest and its associated SNPs.
#'
#' This is a wrapper function for the other functions in this package.
#'
#' @param outcome a vector of the outcome trait
#' @param snps a matrix/vector of SNPs
#' @param mediators a matrix/vector of mediators
#' @param covariates a matrix/vector of covariates
#' @param em_iter the number of EM iterations that the median should be taken from
#' @param c the chain length
#' @param burn the burn-in length
#' @param remove_outliers whether SNP effect outliers should be removed. The outliers are not removed be default
#' @param format_snp_code whether the SNP codding should be formatted such that all the SNPs have a positive effec
#' on the outcome trait
#' @param flip whether the MCMC procedure should be conducted again on the label flipped Gaussian mixture model (GMM)
#'  if the HDI and the QI are wider than the threshold
#' @param interval_thres the interval width threshold. If the both the HDI and the QI are wider than this threshold,
#' the label of the two distributions will be flipped, and the MCMC procedure will be run again on the label flipped Gaussian mixture mode
#' (GMM).
#' @param p A value between 0 and 1. Specifies what percentage quantile interval (QI) and highest density interval (HDI) will be calculated.
#'
#' @return A list of the results
#' \itemize{
#' \item bH_median - a point estimate of the hidden mediator's effect size via the posterior median
#' \item bH_mean - a point estimate of the hidden mediator's effect size via the posterior mean
#' \item bH_mode - a point estimate of the hidden mediator's effect size via the posterior mode
#' \item GMM_summary_c - fitted GMM parameters on the estimated direct effects between the SNPs and the outcome (c*)
#' \item GMM_summary_a - fitted GMM parameter on the estimated SNP effects on the known mediators (a*)
#' \item HDI - the highest density interval based on the posterior distribution of bH
#' \item QI - the quantile interval interval based on the posterior distribution of bH
#' \item flipped - whether the MCMC procedure was conducted again on the label flipped GMM
#' }
#'
#'
#' @importFrom stats quantile
#' @importFrom stats density
#' @importFrom HDInterval hdi
#' @importFrom graphics hist
#' @importFrom graphics abline
#' @importFrom graphics lines
#' @importFrom grDevices boxplot.stats
#' @importFrom stats dnorm
#' @examples
#' ## an simple example with three know mediators and one hidden mediator
#' ## simulate data
#' set.seed(1000)
#' true_hidden <- 0.3               # the hidden mediator's effetc size
#' num_snp <-   70                  # number of snp in the model
#' freq <- c(0.5, 0.9, 0.3, 0.6)    # freq of m1, m2, m_Hidden
#' known_beta <- c(0.4, 0.2, 0.25)  # beta1 and beta2, beta3, beat4, beta5
#' sample_size <- 100000
#'
#'
#' ## the snp names
#' snp_col <- c()
#' for (i in 1:num_snp) {
#'   snp_col[i] <- paste("snp", i, sep="")
#' }
#' df.snp <- data.frame(matrix(vector(), sample_size, length(snp_col),
#'                             dimnames=list(c(), snp_col)),
#'                      stringsAsFactors=F)
#' ## generate snps
#' for (i in 1:length(snp_col)) {
#'   ## frequency of the SNPs
#'   w_freq <- runif(n = 1, min = 0.1, max = 0.9)
#'   cur_snp_v <- sample(c(0, 1, 2), size = sample_size, replace = TRUE,
#'                       prob = c((1-w_freq)^2, 2*w_freq*(1-w_freq), w_freq^2))
#'   cur_snp_name <- paste(snp_col[i])
#'   assign(cur_snp_name, cur_snp_v)
#'   df.snp[[cur_snp_name]] <- cur_snp_v
#' }
#'
#' upper_level_effect <- rnorm(n = length(known_beta)+1, 0.2, 0)
#'
#' ############# known: m1
#' # a vector of indicator of presence
#' idc1 <- sample(c(0, 1), size = num_snp, replace = TRUE,
#' prob = c(1-freq[1], freq[1]))
#' ## set the mean SNP effect to 0.2
#' SNP_beta1 <- rnorm(n = num_snp, mean = 0.2, sd = 0.08)
#' m1 <- (data.matrix(df.snp) %*% (idc1 * SNP_beta1))[,1]
#' m1 <- m1 + rnorm(sample_size, mean = 0, sd = 1) + 5
#'
#' ############# known: m2
#' # a vector of indicator of presence
#' idc2 <- sample(c(0, 1), size = num_snp, replace = TRUE,
#' prob = c(1-freq[2], freq[2]))
#' ## set the mean SNP effect to 0.2
#' SNP_beta2 <- rnorm(n = num_snp, mean = 0.2, sd = 0.08)
#' m2 <- (data.matrix(df.snp) %*% (idc2 * SNP_beta2))[,1]
#' m2 <- m2 + rnorm(sample_size, mean = 0, sd = 1) + 10
#'
#' ############# known: m3
#' # a vector of indicator of presence
#' idc3 <- sample(c(0, 1), size = num_snp, replace = TRUE,
#' prob = c(1-freq[3], freq[3]))
#' ## set the mean SNP effect to 0.2
#' SNP_beta3 <- rnorm(n = num_snp, mean = 0.2, sd = 0.08)
#' m3 <- (data.matrix(df.snp) %*% (idc3 * SNP_beta3))[,1]
#' m3 <- m3 + rnorm(sample_size, mean = 0, sd = 1) + 2
#'
#' ############# hidden: m4
#' # a vector of indicator of presence
#' idc4 <- sample(c(0, 1), size = num_snp, replace = TRUE,
#' prob = c(1-freq[4], freq[4]))
#' ## set the mean SNP effect to 0.2
#' SNP_beta4 <- rnorm(n = num_snp, mean = 0.2, sd = 0.08)
#' m4 <- (data.matrix(df.snp) %*% (idc4 * SNP_beta4))[,1]
#' m4 <- m4 + rnorm(sample_size, mean = 0, sd = 1) + 8
#'
#' ############# covariates
#' covariate1 <- rnorm(sample_size, mean = 7, sd = 0.5)
#' covariate2 <- rnorm(sample_size, mean = 4, sd = 0.4)
#'
#' ############## outcome
#' y <- known_beta[1] * m1 + known_beta[2] * m2 + known_beta[3] * m3 +
#'   true_hidden * m4 + 0.8 * covariate1 - 0.3 * covariate2 +
#'   rnorm(sample_size, mean = 0, sd = 0.2)
#'
#' ## put together with the SNPs
#' df.snp$m1 <- m1
#' df.snp$m2 <- m2
#' df.snp$m3 <- m3
#' df.snp$m4 <- m4
#' df.snp$y <- y
#' df.snp$covariate1 <- covariate1
#' df.snp$covariate2 <- covariate2
#'
#' ## 70 SNPs
#' outcome <- df.snp$y
#' snps <- as.matrix(df.snp[,1:70])
#' mediators <- as.matrix(df.snp[,71:73])
#' covariates <- as.matrix(df.snp[76:77])
#'
#' ## estimate the hidden mediator's effect size
#' result <- estimateHM(outcome, snps, mediators, covariates, em_iter = 15,
#' c = 10000, burn = 1000, remove_outliers = FALSE)
#' result
#'
#'
#' @export
#'
estimateHM <- function(outcome, snps, mediators, covariates, em_iter = 15, c = 10000,
                       burn = 1000, remove_outliers = FALSE, format_snp_code = FALSE,
                       flip = FALSE, interval_thres = 5, p = 0.9) {

  #### check if input parameters are valid
  if (is.vector(outcome) == FALSE) {
    print("Error: outcome should be a vector")
    return()
  }
  if (is.matrix(snps) == FALSE) {
    print("Error: snps should be a matrix")
    return()
  }
  if (is.matrix(mediators) == FALSE) {
    print("Error: mediators should be a matrix")
    return()
  }
  if (is.matrix(covariates) == FALSE) {
    print("Error: covariates should be a matrix")
    return()
  }

  ### int check funtion
  check_pos_int <- function(x) {
    flag <- TRUE
    if (length(x) > 1) {
      flag <- FALSE
      return(flag)
    }
    if (x %% 1 != 0) {flag <- FALSE}
    if (x <= 1) {flag <- FALSE}
    return(flag)
  }
  ### checking int
  if (check_pos_int(em_iter) == FALSE) {
    print("Error: em_iter should be a single positive integer")
    return()
  }
  if (check_pos_int(c) == FALSE) {
    print("Error: c should be a single positive integer")
    return()
  }
  if (check_pos_int(burn) == FALSE) {
    print("Error: burn should be a single positive integer")
    return()
  }
  if ((length(interval_thres) > 1)  | (interval_thres <= 0)) {
    print("Error: interval_thres should be a single positive number")
    return()
  }
  if ((length(remove_outliers) > 1)  | (is.logical(remove_outliers) ==FALSE)) {
    print("Error: remove_outliers should be a single logical object")
    return()
  }
  if ((length(format_snp_code) > 1)  | (is.logical(format_snp_code) ==FALSE)) {
    print("Error: format_snp_code should be a single logical object")
    return()
  }
  if ((length(flip) > 1)  | (is.logical(flip) ==FALSE)) {
    print("Error: flip should be a single logical object")
    return()
  }


  #### check if the outcome, snps, mediators, covariates have the correct number of subjects
  if (is.vector(outcome)) {
    n_outcome <- length(outcome)
  } else {
    print("Error: This package currently only supports one outcome trait")
    return()
  }

  if (is.vector(snps)) {
    n_snp <- length(snps)
  } else {
    n_snp <- nrow(snps)
  }

  if (is.vector(mediators)) {
    n_mediator <- length(mediators)
  } else {
    n_mediator <- nrow(mediators)
  }

  if (is.vector(covariates)) {
    n_covariate <- length(covariates)
  } else {
    n_covariate <- nrow(covariates)
  }

  if (  length( unique(c(n_outcome, n_snp, n_mediator, n_covariate))  ) > 1 ) {
    print("Error: Different sample sizes among the outcome, the SNP(s), the mediator(s), and the covariate(s).")
    return()
  }


  #### Step0: preprocess
  if (format_snp_code) {
    snps <- flipSNP(snps = snps, outcome = outcome, covariates = covariates)
  }

  #### Step1: regressions
  a_star <- mediatorReg(snps = snps, mediators = mediators, covariates = covariates)
  c_star <- outcomeReg(outcome = outcome, snps = snps, mediators = mediators,
                       covariates = covariates)

  #### remove outliers
  if (remove_outliers) {
    out.a <- boxplot.stats(a_star, coef = 3)$out
    a_star.red <- a_star[!a_star %in% out.a]
    print(paste("# points removed in a: ", length( out.a)))

    out.c <- boxplot.stats(c_star, coef = 3)$out
    c_star.red <- c_star[!c_star %in% out.c]
    print(paste("# points removed in c: ", length( out.c)))

    out <- c(out.a, out.c)

    a_star <- a_star[!a_star %in% out]
    c_star <- c_star[!c_star %in% out]
  }


  #### Step2: GMM hypothesis test
  #### Step3: EM
  em_result.a <-median_EM(x = a_star, iteration = em_iter)
  emSummary.a <- em_result.a$emSummary
  em_result.c <-median_EM(x = c_star, iteration = em_iter)
  emSummary.c <- em_result.c$emSummary

  ## plot the GMMs
  graphics::hist(a_star, breaks = 30, main = "a_star", freq = FALSE)
  x <- seq(min(a_star), max(a_star), length = 100)
  dens_a1 <- stats::dnorm(x, mean = emSummary.a$mean[1], sd = emSummary.a$sd[1]) * emSummary.a$lambda[1]
  graphics::lines(x, dens_a1, col = "blue", lwd = 2)
  graphics::abline(v = emSummary.a$mean[1], col = "blue")
  dens_a2 <- stats::dnorm(x, mean = emSummary.a$mean[2], sd = emSummary.a$sd[2]) * emSummary.a$lambda[2]
  graphics::lines(x, dens_a2, col = "green", lwd = 2)
  graphics::abline(v = emSummary.a$mean[2], col = "green")

  graphics::hist(c_star, breaks = 30, main = "c_star", freq = FALSE)
  x <- seq(min(c_star), max(c_star), length = 100)
  dens_c1 <- stats::dnorm(x, mean = emSummary.c$mean[1], sd = emSummary.c$sd[1]) * emSummary.c$lambda[1]
  graphics::lines(x, dens_c1, col = "blue", lwd = 2)
  graphics::abline(v = emSummary.c$mean[1], col = "blue")
  dens_c2 <- stats::dnorm(x, mean = emSummary.c$mean[2], sd = emSummary.c$sd[2]) * emSummary.c$lambda[2]
  graphics::lines(x, dens_c2, col = "green", lwd = 2)
  graphics::abline(v = emSummary.c$mean[2], col = "green")



  #### Step4: MCMC
  flipped <- FALSE
  chain <- MCMC_GMM(c_star = c_star, emSummary.a = emSummary.a,
           emSummary.c = emSummary.c, c = c, burn = burn)

  ### point estimators for bH
  bH_median <- stats::quantile(chain[,1], 0.5)
  bH_mean <- mean(chain[,1])

  td <- density(chain[,1])
  max_index <- which.max(td$y)
  bH_mode <- td$x[max_index]

  # 90% quantile QI
  bH_QI_low <- stats::quantile(chain[,1], (1 - p ) / 2)
  bH_QI_up <- stats::quantile(chain[,1], 1 - (1 - p ) / 2)

  # 90% HDI
  bH_HDI_low <- HDInterval::hdi(chain[,1], credMass = p)[1]
  bH_HDI_up <- HDInterval::hdi(chain[,1], credMass = p)[2]

  emSummary.c.flip <- emSummary.c

  ### if the MCMC is very unstable
  QI_width <- bH_QI_up - bH_QI_low
  HDI_width <- bH_HDI_up - bH_HDI_low
  if ((QI_width > interval_thres) & (HDI_width > interval_thres)) {

    ## the GMM labeling has been flipped
    flipped <- TRUE
    emSummary.c.flip$sd <- c(emSummary.c.flip$sd[2], emSummary.c.flip$sd[1])
    emSummary.c.flip$lambda <- c(emSummary.c.flip$lambda[2], emSummary.c.flip$lambda[1])
    chain <- MCMC_GMM(c_star = c_star, emSummary.a = emSummary.a,
                      emSummary.c = emSummary.c.flip, c = c, burn = burn)

    ### point estimators for bH
    bH_median <- stats::quantile(chain[,1], 0.5)
    bH_mean <- mean(chain[,1])

    td <- density(chain[,1])
    max_index <- which.max(td$y)
    bH_mode <- td$x[max_index]

    # 90% quantile CI
    bH_QI_low <- stats::quantile(chain[,1], 0.05)
    bH_QI_up <- stats::quantile(chain[,1], 0.95)
    QI <- c(bH_QI_low, bH_QI_up)
    names(QI) <- c("", "")

    # 90% HDI
    bH_HDI_low <- HDInterval::hdi(chain[,1], credMass = 0.9)[1]
    bH_HDI_up <- HDInterval::hdi(chain[,1], credMass = 0.9)[2]
    HDI <- c(bH_HDI_low, bH_HDI_up)
    names(HDI) <- c("", "")

  }
  estimates <- list(bH_median = bH_median, bH_mean = bH_mean, bH_mode = bH_mode,
                    GMM_summary_c = emSummary.c.flip, GMM_summary_a = emSummary.a,
                    HDI = c(bH_HDI_low, bH_HDI_up),
                    QI = c(bH_QI_low, bH_QI_up),
                    flipped = flipped)
  names(estimates$HDI) <- c(paste((1 - p)/2*100, "%", sep = ""), paste((1 - (1 - p ) / 2)*100, "%", sep = ""))
  return(estimates)

}
