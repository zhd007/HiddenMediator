#' Perform the outcome regression
#'
#' @param outcome a vector of the outcome trait
#' @param snps a matrix/vector of SNPs
#' @param mediators a matrix/vector of mediators
#' @param covariates a matrix/vector of covariates
#'
#' @return a vector of regression estimated direct effects between the SNPs and the outcome (c*)
#' @importFrom stats lm
#' @export
#'
outcomeReg <- function(outcome, snps, mediators, covariates) {

  if (is.vector(snps)) {
    numSnp <- 1
  } else {
    numSnp <- ncol(snps)
  }

  if (is.vector(mediators)) {
    numMed <- 1
  } else {
    numMed <- ncol(mediators)
  }

  if (is.vector(covariates)) {
    numCov <- 1
  } else {
    numCov <- ncol(covariates)
  }

  regDf <- cbind(matrix(outcome, ncol = 1), matrix(mediators, ncol = numMed),
                 matrix(snps, ncol = numSnp), matrix(covariates, ncol = numCov))
  colnames(regDf) <- c("outcome", paste("m", 1:numMed, sep = ""),
                       paste("snp", 1:numSnp, sep = ""),
                       paste("cov", 1:numCov, sep = ""))

  med_names <- paste("m", 1:numMed, sep = "")
  med_string <- do.call(paste, c(as.list(med_names), sep = "+"))
  snp_names <- paste("snp", 1:numSnp, sep = "")
  snp_string <- do.call(paste, c(as.list(snp_names), sep = "+"))
  cov_names <- paste("cov", 1:numCov, sep = "")
  cov_string <- do.call(paste, c(as.list(cov_names), sep = "+"))
  outcome_eq <-  paste("outcome~", snp_string, "+", med_string, "+", cov_string, sep = "")
  #print(outcome_eq)
  outcome_model <- stats::lm(outcome_eq, data = data.frame(regDf))
  c_star <- c(outcome_model$coefficients[2:(2+numSnp-1)])
  return(c_star)

}

