#' Perform the mediator regression(s)
#'
#' @param snps a matrix/vector of SNPs
#' @param mediators a matrix/vector of mediators
#' @param covariates a matrix/vector of covariates
#'
#' @return a vector of regression estimated SNP effects on the mediators (a*)
#' @importFrom stats lm
#' @export
#'
mediatorReg <- function(snps, mediators, covariates) {

  if (is.vector(snps)) {
    numSnp <- 1
  } else {
    numSnp <- ncol(snps)
  }

  if (is.vector(mediators)) {
    numMed <- 1
  } else {
    numMed <- ncol(mediators)
  }

  if (is.vector(covariates)) {
    numCov <- 1
  } else {
    numCov <- ncol(covariates)
  }

  regDf <- cbind(matrix(mediators, ncol = numMed), matrix(snps, ncol = numSnp),
                 matrix(covariates, ncol = numCov))
  colnames(regDf) <- c(paste("m", 1:numMed, sep = ""),
                       paste("snp", 1:numSnp, sep = ""),
                       paste("cov", 1:numCov, sep = ""))

  a_star <- -99
  for (i in 1:numMed) {
    snp_names <- paste("snp", 1:numSnp, sep = "")
    snp_string <- do.call(paste, c(as.list(snp_names), sep = "+"))
    cov_names <- paste("cov", 1:numCov, sep = "")
    cov_string <- do.call(paste, c(as.list(cov_names), sep = "+"))
    mediator_eq <-  paste("m", i, "~", snp_string, "+", cov_string, sep = "")
    #print(mediator_eq)
    mediator_model <- stats::lm(mediator_eq, data = data.frame(regDf))
    a_star <- c(a_star, mediator_model$coefficients[2:(2+numSnp-1)])
  }
  a_star <- a_star[2:length(a_star)]
  return(a_star)
}
