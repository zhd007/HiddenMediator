#' Fit GMM models via MCMC
#'
#' @param c_star a vector of regression estimated direct effects between the SNPs and the outcome (c*)
#' @param emSummary.a a dataframe of GMM parameters of a_star
#' @param emSummary.c a dataframe of GMM parameters of c_star
#' @param c the chain length
#' @param burn the burn-in length
#'
#' @return the MCMC chain
#' @importFrom rjags jags.model
#' @importFrom stats update
#' @importFrom rjags coda.samples
#' @importFrom coda as.mcmc
#' @export
#'
MCMC_GMM <- function(c_star, emSummary.a, emSummary.c, c, burn) {
  mu_a <- emSummary.a$mean[2]
  sd_c1 <- emSummary.c$sd[1]
  sd_c2 <- emSummary.c$sd[2]
  pi <- emSummary.c$lambda

  model_string = "model {

  for (i in 1:n) {
  c[i] ~ dnorm(mu[z[i]], prec[z[i]])
  z[i] ~ dcat(pi)
  }


  mu[2] = bH * mu_a
  mu[1] = 0

  prec[1] = 1/(sd_c1^2)
  prec[2] = 1/(sd_c2^2)

  bH ~ dnorm(0, 1/100)

  }"


  data_jags <- list(c = c_star, mu_a = mu_a,
                    sd_c1 = sd_c1, sd_c2 = sd_c2,
                    n = length(c_star),
                    pi = pi)

  inits_jags <- list(bH = 0)

  params <- c("bH")
  mod <- rjags::jags.model(textConnection(model_string), data=data_jags, n.chains=1, inits = inits_jags)

  ## burn in
  stats::update(mod, n.iter=burn)

  ## actual chain
  mod_sim <- rjags::coda.samples(model=mod, variable.names=params, n.iter=c)
  chain <- coda::as.mcmc(do.call(rbind, mod_sim))
  return(chain)
}
