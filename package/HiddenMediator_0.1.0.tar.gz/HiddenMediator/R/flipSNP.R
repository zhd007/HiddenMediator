#' Recode the SNPs
#'
#' Recode the SNPs such that all SNPs have positive effects on the outcome.
#'
#' @param snps a matrix/vector of SNPs
#' @param outcome a vector of the outcome trait
#' @param covariates a matrix/vector of covariates
#'
#' @return a matrix of recoded SNPs such that all the SNPs have positive effects on the outcome
#' @importFrom stats lm
#' @export
#'
flipSNP <- function(snps, outcome, covariates) {

  if (is.vector(snps)) {
    numSnp <- 1
  } else {
    numSnp <- ncol(snps)
  }
  if (is.vector(covariates)) {
    numCov <- 1
  } else {
    numCov <- ncol(covariates)
  }
  regDf <- cbind(matrix(outcome, ncol = 1), matrix(snps, ncol = numSnp),
                 matrix(covariates, ncol = numCov))
  colnames(regDf) <- c("outcome", paste("snp", 1:numSnp, sep = ""),
                       paste("cov", 1:numCov, sep = ""))

  ## get the sign
  snp_names <- paste("snp", 1:numSnp, sep = "")
  snp_string <- do.call(paste, c(as.list(snp_names), sep = "+"))
  cov_names <- paste("cov", 1:numCov, sep = "")
  cov_string <- do.call(paste, c(as.list(cov_names), sep = "+"))
  outcome_eq <-  paste("outcome~", snp_string, "+", cov_string, sep = "")
  outcome_model <- stats::lm(outcome_eq, data = data.frame(regDf))
  flip_index <- which(outcome_model$coefficients[2:(2+numSnp-1)] < 0)

  ## flip the snps
  if( length(flip_index) == 0) {
    return(snps)
  } else {
    snps.flipped <- snps
    for (i in 1:length(flip_index)) {
      index <- flip_index[i]
      snps.flipped[,index][snps.flipped[,index] == 0] <- -2
      snps.flipped[,index][snps.flipped[,index] == 2 ] <- 0
      snps.flipped[,index][snps.flipped[,index] == -2 ] <- 2

    }
    return(snps.flipped)
  }
}
