#' Fit a Gaussian mixture model (GMM) model via EM
#'
#' @param x the input vector for EM
#' @param iteration the number of EM iterations that the median should be taken from
#'
#' @return A list of two elements
#' \itemize{
#' \item medianModel - the EM model with the median estimate among all the iterations
#' \item emSummary - a dataframe of the fitted GMM parameters of the median EM model.
#' }
#'
#' @importFrom SimDesign quiet
#' @importFrom mixtools normalmixEM
#' @importFrom stats median
#' @export
#'
median_EM <- function(x, iteration = 15) {

  emMu2 <- vector(mode = "logical", length = iteration)
  emModel <- vector(mode = "list", length = iteration)

  for (em_i in 1:iteration) {
    em_status <- -999
    while (em_status == -999) {
      tryCatch({
        snp_em <- SimDesign::quiet(mixtools::normalmixEM(x,
                                      lambda = .5, arbvar = TRUE), messages = TRUE)
        em_status <- 1
      }, error=function(e){
        print("caught")
        em_status <- -999})
    }

    emMu2[em_i] <- snp_em$mu[2]
    emModel[[em_i]] <- snp_em
  }

  medianI <- which(round(emMu2, digits = 6) == round(stats::median(emMu2), digits = 6))[1]
  medianModel <- emModel[[medianI]]
  snp_em_summary <- data.frame("mean" = medianModel$mu,
                               "sd" = medianModel$sigma,
                               "lambda" = medianModel$lambda )
  return(list(medianModel = medianModel, emSummary = snp_em_summary))
}
