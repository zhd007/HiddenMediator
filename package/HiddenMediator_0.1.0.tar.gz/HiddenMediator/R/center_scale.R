#' Scale the mediator vector
#'
#' @param data_vector the mediator vector to be cented and scaled
#'
#' @return a centered and scaled vector
#' @export
#'
#' @examples center_scale(c(1,2,3,4))
center_scale <- function(data_vector) {
  return(scale(data_vector, center = TRUE, scale = TRUE))
}
